"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _configSchema = require("@osd/config-schema");

var _common = require("../../common");

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
// TODO: consider to extract entity CRUD operations and put it into a client class
function defineRoutes(router) {
  const internalUserSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    password: _configSchema.schema.maybe(_configSchema.schema.string()),
    backend_roles: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    attributes: _configSchema.schema.any({
      defaultValue: {}
    })
  });

  const actionGroupSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    allowed_actions: _configSchema.schema.arrayOf(_configSchema.schema.string()) // type field is not supported in legacy implementation, comment it out for now.
    // type: schema.oneOf([
    //   schema.literal('cluster'),
    //   schema.literal('index'),
    //   schema.literal('opensearch_dashboards'),
    // ]),

  });

  const roleMappingSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    backend_roles: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    hosts: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    users: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    })
  });

  const roleSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    cluster_permissions: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    tenant_permissions: _configSchema.schema.arrayOf(_configSchema.schema.any(), {
      defaultValue: []
    }),
    index_permissions: _configSchema.schema.arrayOf(_configSchema.schema.any(), {
      defaultValue: []
    })
  });

  const tenantSchema = _configSchema.schema.object({
    description: _configSchema.schema.string()
  });

  const accountSchema = _configSchema.schema.object({
    password: _configSchema.schema.string(),
    current_password: _configSchema.schema.string()
  });

  const schemaMap = {
    internalusers: internalUserSchema,
    actiongroups: actionGroupSchema,
    rolesmapping: roleMappingSchema,
    roles: roleSchema,
    tenants: tenantSchema,
    account: accountSchema
  };

  function validateRequestBody(resourceName, requestBody) {
    const inputSchema = schemaMap[resourceName];

    if (!inputSchema) {
      throw new Error(`Unknown resource ${resourceName}`);
    }

    inputSchema.validate(requestBody); // throws error if validation fail
  }

  function validateEntityId(resourceName) {
    if (!(0, _common.isValidResourceName)(resourceName)) {
      return 'Invalid entity name or id.';
    }
  }
  /**
   * Lists resources by resource name.
   *
   * The response format is:
   * {
   *   "total": <total_entity_count>,
   *   "data": {
   *     "entity_id_1": { <entity_structure> },
   *     "entity_id_2": { <entity_structure> },
   *     ...
   *   }
   * }
   *
   * e.g. when listing internal users, response may look like:
   * {
   *   "total": 2,
   *   "data": {
   *     "api_test_user2": {
   *       "hash": "",
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "attributes": {},
   *       "description": "",
   *       "static": false
   *     },
   *     "api_test_user1": {
   *       "hash": "",
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "attributes": {},
   *       "static": false
   *     }
   * }
   *
   * when listing action groups, response will look like:
   * {
   *   "total": 2,
   *   "data": {
   *     "read": {
   *       "reserved": true,
   *       "hidden": false,
   *       "allowed_actions": ["indices:data/read*", "indices:admin/mappings/fields/get*"],
   *       "type": "index",
   *       "description": "Allow all read operations",
   *       "static": false
   *     },
   *     "cluster_all": {
   *       "reserved": true,
   *       "hidden": false,
   *       "allowed_actions": ["cluster:*"],
   *       "type": "cluster",
   *       "description": "Allow everything on cluster level",
   *       "static": false
   *     }
   * }
   *
   * role:
   * {
   *   "total": 2,
   *   "data": {
   *     "opensearch_dashboards_user": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Provide the minimum permissions for a opensearch_dashboards user",
   *       "cluster_permissions": ["cluster_composite_ops"],
   *       "index_permissions": [{
   *         "index_patterns": [".opensearch_dashboards", ".opensearch_dashboards-6", ".opensearch_dashboards_*"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["read", "delete", "manage", "index"]
   *       }, {
   *         "index_patterns": [".tasks", ".management-beats"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["indices_all"]
   *       }],
   *       "tenant_permissions": [],
   *       "static": false
   *     },
   *     "all_access": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Allow full access to all indices and all cluster APIs",
   *       "cluster_permissions": ["*"],
   *       "index_permissions": [{
   *         "index_patterns": ["*"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["*"]
   *       }],
   *       "tenant_permissions": [{
   *         "tenant_patterns": ["*"],
   *         "allowed_actions": ["opensearch_dashboards_all_write"]
   *       }],
   *       "static": false
   *     }
   *   }
   * }
   *
   * rolesmapping:
   * {
   *   "total": 2,
   *   "data": {
   *     "security_manager": {
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "hosts": [],
   *       "users": ["zengyan", "admin"],
   *       "and_backend_roles": []
   *     },
   *     "all_access": {
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "hosts": [],
   *       "users": ["zengyan", "admin", "indextest"],
   *       "and_backend_roles": []
   *     }
   *   }
   * }
   *
   * tenants:
   * {
   *   "total": 2,
   *   "data": {
   *     "global_tenant": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Global tenant",
   *       "static": false
   *     },
   *     "test tenant": {
   *       "reserved": false,
   *       "hidden": false,
   *       "description": "tenant description",
   *       "static": false
   *     }
   *   }
   * }
   */


  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.listResource', {
        resourceName: request.params.resourceName
      });
      return response.ok({
        body: {
          total: Object.keys(esResp).length,
          data: esResp
        }
      });
    } catch (error) {
      console.log(JSON.stringify(error));
      return errorResponse(response, error);
    }
  });
  /**
   * Gets entity by id.
   *
   * the response format differs from different resource types. e.g.
   *
   * for internal user, response will look like:
   * {
   *   "hash": "",
   *   "reserved": false,
   *   "hidden": false,
   *   "backend_roles": [],
   *   "attributes": {},
   *   "static": false
   * }
   *
   * for role, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Allow full access to all indices and all cluster APIs",
   *   "cluster_permissions": ["*"],
   *   "index_permissions": [{
   *     "index_patterns": ["*"],
   *     "fls": [],
   *     "masked_fields": [],
   *     "allowed_actions": ["*"]
   *   }],
   *   "tenant_permissions": [{
   *     "tenant_patterns": ["*"],
   *     "allowed_actions": ["opensearch_dashboards_all_write"]
   *   }],
   *   "static": false
   * }
   *
   * for roles mapping, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Allow full access to all indices and all cluster APIs",
   *   "cluster_permissions": ["*"],
   *   "index_permissions": [{
   *     "index_patterns": ["*"],
   *     "fls": [],
   *     "masked_fields": [],
   *     "allowed_actions": ["*"]
   *   }],
   *   "tenant_permissions": [{
   *     "tenant_patterns": ["*"],
   *     "allowed_actions": ["opensearch_dashboards_all_write"]
   *   }],
   *   "static": false
   * }
   *
   * for action groups, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "allowed_actions": ["indices:data/read*", "indices:admin/mappings/fields/get*"],
   *   "type": "index",
   *   "description": "Allow all read operations",
   *   "static": false
   * }
   *
   * for tenant, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Global tenant",
   *   "static": false
   * },
   */

  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.getResource', {
        resourceName: request.params.resourceName,
        id: request.params.id
      });
      return response.ok({
        body: esResp[request.params.id]
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Deletes an entity by id.
   */

  router.delete({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string({
          minLength: 1
        })
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.deleteResource', {
        resourceName: request.params.resourceName,
        id: request.params.id
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Update object with out Id. Resource identification is expected to computed from headers. Eg: auth headers
   *
   * Request sample:
   * /configuration/account
   * {
   *   "password": "new-password",
   *   "current_password": "old-password"
   * }
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string()
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    try {
      validateRequestBody(request.params.resourceName, request.body);
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }

    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.saveResourceWithoutId', {
        resourceName: request.params.resourceName,
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Update entity by Id.
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string({
          validate: validateEntityId
        })
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    try {
      validateRequestBody(request.params.resourceName, request.body);
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }

    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.saveResource', {
        resourceName: request.params.resourceName,
        id: request.params.id,
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets authentication info of the user.
   *
   * The response looks like:
   * {
   *   "user": "User [name=admin, roles=[], requestedTenant=__user__]",
   *   "user_name": "admin",
   *   "user_requested_tenant": "__user__",
   *   "remote_address": "127.0.0.1:35044",
   *   "backend_roles": [],
   *   "custom_attribute_names": [],
   *   "roles": ["all_access", "security_manager"],
   *   "tenants": {
   *     "another_tenant": true,
   *     "admin": true,
   *     "global_tenant": true,
   *     "aaaaa": true,
   *     "test tenant": true
   *   },
   *   "principal": null,
   *   "peer_certificates": "0",
   *   "sso_logout_url": null
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/auth/authinfo`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.authinfo');
      return response.ok({
        body: esResp
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets audit log configuration。
   *
   * Sample payload:
   * {
   *   "enabled":true,
   *   "audit":{
   *     "enable_rest":false,
   *     "disabled_rest_categories":[
   *       "FAILED_LOGIN",
   *       "AUTHENTICATED"
   *     ],
   *     "enable_transport":true,
   *     "disabled_transport_categories":[
   *       "GRANTED_PRIVILEGES"
   *     ],
   *     "resolve_bulk_requests":true,
   *     "log_request_body":false,
   *     "resolve_indices":true,
   *     "exclude_sensitive_headers":true,
   *     "ignore_users":[
   *       "admin",
   *     ],
   *     "ignore_requests":[
   *       "SearchRequest",
   *       "indices:data/read/*"
   *     ]
   *   },
   *   "compliance":{
   *     "enabled":true,
   *     "internal_config":false,
   *     "external_config":false,
   *     "read_metadata_only":false,
   *     "read_watched_fields":{
   *       "indexName1":[
   *         "field1",
   *         "fields-*"
   *       ]
   *     },
   *     "read_ignore_users":[
   *       "opensearchdashboardsserver",
   *       "operator/*"
   *     ],
   *     "write_metadata_only":false,
   *     "write_log_diffs":false,
   *     "write_watched_indices":[
   *       "indexName2",
   *       "indexPatterns-*"
   *     ],
   *     "write_ignore_users":[
   *       "admin"
   *     ]
   *   }
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/configuration/audit`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.getAudit');
      return response.ok({
        body: esResp
      });
    } catch (error) {
      return response.custom({
        statusCode: error.statusCode,
        body: parseEsErrorResponse(error)
      });
    }
  });
  /**
   * Update audit log configuration。
   *
   * Sample payload:
   * {
   *   "enabled":true,
   *   "audit":{
   *     "enable_rest":false,
   *     "disabled_rest_categories":[
   *       "FAILED_LOGIN",
   *       "AUTHENTICATED"
   *     ],
   *     "enable_transport":true,
   *     "disabled_transport_categories":[
   *       "GRANTED_PRIVILEGES"
   *     ],
   *     "resolve_bulk_requests":true,
   *     "log_request_body":false,
   *     "resolve_indices":true,
   *     "exclude_sensitive_headers":true,
   *     "ignore_users":[
   *       "admin",
   *     ],
   *     "ignore_requests":[
   *       "SearchRequest",
   *       "indices:data/read/*"
   *     ]
   *   },
   *   "compliance":{
   *     "enabled":true,
   *     "internal_config":false,
   *     "external_config":false,
   *     "read_metadata_only":false,
   *     "read_watched_fields":{
   *       "indexName1":[
   *         "field1",
   *         "fields-*"
   *       ]
   *     },
   *     "read_ignore_users":[
   *       "kibanaserver",
   *       "operator/*"
   *     ],
   *     "write_metadata_only":false,
   *     "write_log_diffs":false,
   *     "write_watched_indices":[
   *       "indexName2",
   *       "indexPatterns-*"
   *     ],
   *     "write_ignore_users":[
   *       "admin"
   *     ]
   *   }
   * }
   */

  router.post({
    path: `${_common.API_PREFIX}/configuration/audit/config`,
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opensearch_security.saveAudit', {
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Deletes cache.
   *
   * Sample response: {"message":"Cache flushed successfully."}
   */

  router.delete({
    path: `${_common.API_PREFIX}/configuration/cache`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResponse;

    try {
      esResponse = await client.callAsCurrentUser('opensearch_security.clearCache');
      return response.ok({
        body: {
          message: esResponse.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets permission info of current user.
   *
   * Sample response:
   * {
   *   "user": "User [name=admin, roles=[], requestedTenant=__user__]",
   *   "user_name": "admin",
   *   "has_api_access": true,
   *   "disabled_endpoints": {}
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/restapiinfo`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opensearch_security.restapiinfo');
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }
  });
  /**
   * Validates DLS (document level security) query.
   *
   * Request payload is an ES query.
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/validatedls/{indexName}`,
    validate: {
      params: _configSchema.schema.object({
        // in legacy plugin implmentation, indexName is not used when calling ES API.
        indexName: _configSchema.schema.maybe(_configSchema.schema.string())
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opensearch_security.validateDls', {
        body: request.body
      });
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets index mapping.
   *
   * Calling ES _mapping API under the hood. see
   * https://www.elastic.co/guide/en/elasticsearch/reference/current/indices-get-mapping.html
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/index_mappings`,
    validate: {
      body: _configSchema.schema.object({
        index: _configSchema.schema.arrayOf(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opensearch_security.getIndexMappings', {
        index: request.body.index.join(','),
        ignore_unavailable: true,
        allow_no_indices: true
      });
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets all indices, and field mappings.
   *
   * Calls ES API '/_all/_mapping/field/*' under the hood. see
   * https://www.elastic.co/guide/en/elasticsearch/reference/current/indices-get-mapping.html
   */

  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/indices`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opensearch_security.indices');
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
}

function parseEsErrorResponse(error) {
  if (error.response) {
    try {
      const esErrorResponse = JSON.parse(error.response);
      return esErrorResponse.reason || error.response;
    } catch (parsingError) {
      return error.response;
    }
  }

  return error.message;
}

function errorResponse(response, error) {
  return response.custom({
    statusCode: error.statusCode,
    body: parseEsErrorResponse(error)
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciIsImludGVybmFsVXNlclNjaGVtYSIsInNjaGVtYSIsIm9iamVjdCIsImRlc2NyaXB0aW9uIiwibWF5YmUiLCJzdHJpbmciLCJwYXNzd29yZCIsImJhY2tlbmRfcm9sZXMiLCJhcnJheU9mIiwiZGVmYXVsdFZhbHVlIiwiYXR0cmlidXRlcyIsImFueSIsImFjdGlvbkdyb3VwU2NoZW1hIiwiYWxsb3dlZF9hY3Rpb25zIiwicm9sZU1hcHBpbmdTY2hlbWEiLCJob3N0cyIsInVzZXJzIiwicm9sZVNjaGVtYSIsImNsdXN0ZXJfcGVybWlzc2lvbnMiLCJ0ZW5hbnRfcGVybWlzc2lvbnMiLCJpbmRleF9wZXJtaXNzaW9ucyIsInRlbmFudFNjaGVtYSIsImFjY291bnRTY2hlbWEiLCJjdXJyZW50X3Bhc3N3b3JkIiwic2NoZW1hTWFwIiwiaW50ZXJuYWx1c2VycyIsImFjdGlvbmdyb3VwcyIsInJvbGVzbWFwcGluZyIsInJvbGVzIiwidGVuYW50cyIsImFjY291bnQiLCJ2YWxpZGF0ZVJlcXVlc3RCb2R5IiwicmVzb3VyY2VOYW1lIiwicmVxdWVzdEJvZHkiLCJpbnB1dFNjaGVtYSIsIkVycm9yIiwidmFsaWRhdGUiLCJ2YWxpZGF0ZUVudGl0eUlkIiwiZ2V0IiwicGF0aCIsIkFQSV9QUkVGSVgiLCJDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVgiLCJwYXJhbXMiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiY2xpZW50Iiwic2VjdXJpdHlfcGx1Z2luIiwiZXNDbGllbnQiLCJhc1Njb3BlZCIsImVzUmVzcCIsImNhbGxBc0N1cnJlbnRVc2VyIiwib2siLCJib2R5IiwidG90YWwiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImxvZyIsIkpTT04iLCJzdHJpbmdpZnkiLCJlcnJvclJlc3BvbnNlIiwiaWQiLCJkZWxldGUiLCJtaW5MZW5ndGgiLCJtZXNzYWdlIiwicG9zdCIsImJhZFJlcXVlc3QiLCJjdXN0b20iLCJzdGF0dXNDb2RlIiwicGFyc2VFc0Vycm9yUmVzcG9uc2UiLCJlc1Jlc3BvbnNlIiwiaW5kZXhOYW1lIiwiaW5kZXgiLCJqb2luIiwiaWdub3JlX3VuYXZhaWxhYmxlIiwiYWxsb3dfbm9faW5kaWNlcyIsImVzRXJyb3JSZXNwb25zZSIsInBhcnNlIiwicmVhc29uIiwicGFyc2luZ0Vycm9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBZUE7O0FBT0E7O0FBdEJBOzs7Ozs7Ozs7Ozs7OztBQXdCQTtBQUNPLFNBQVNBLFlBQVQsQ0FBc0JDLE1BQXRCLEVBQXVDO0FBQzVDLFFBQU1DLGtCQUFrQixHQUFHQyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3ZDQyxJQUFBQSxXQUFXLEVBQUVGLHFCQUFPRyxLQUFQLENBQWFILHFCQUFPSSxNQUFQLEVBQWIsQ0FEMEI7QUFFdkNDLElBQUFBLFFBQVEsRUFBRUwscUJBQU9HLEtBQVAsQ0FBYUgscUJBQU9JLE1BQVAsRUFBYixDQUY2QjtBQUd2Q0UsSUFBQUEsYUFBYSxFQUFFTixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT0ksTUFBUCxFQUFmLEVBQWdDO0FBQUVJLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFoQyxDQUh3QjtBQUl2Q0MsSUFBQUEsVUFBVSxFQUFFVCxxQkFBT1UsR0FBUCxDQUFXO0FBQUVGLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFYO0FBSjJCLEdBQWQsQ0FBM0I7O0FBT0EsUUFBTUcsaUJBQWlCLEdBQUdYLHFCQUFPQyxNQUFQLENBQWM7QUFDdENDLElBQUFBLFdBQVcsRUFBRUYscUJBQU9HLEtBQVAsQ0FBYUgscUJBQU9JLE1BQVAsRUFBYixDQUR5QjtBQUV0Q1EsSUFBQUEsZUFBZSxFQUFFWixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT0ksTUFBUCxFQUFmLENBRnFCLENBR3RDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFSc0MsR0FBZCxDQUExQjs7QUFXQSxRQUFNUyxpQkFBaUIsR0FBR2IscUJBQU9DLE1BQVAsQ0FBYztBQUN0Q0MsSUFBQUEsV0FBVyxFQUFFRixxQkFBT0csS0FBUCxDQUFhSCxxQkFBT0ksTUFBUCxFQUFiLENBRHlCO0FBRXRDRSxJQUFBQSxhQUFhLEVBQUVOLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWYsRUFBZ0M7QUFBRUksTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDLENBRnVCO0FBR3RDTSxJQUFBQSxLQUFLLEVBQUVkLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWYsRUFBZ0M7QUFBRUksTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDLENBSCtCO0FBSXRDTyxJQUFBQSxLQUFLLEVBQUVmLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWYsRUFBZ0M7QUFBRUksTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDO0FBSitCLEdBQWQsQ0FBMUI7O0FBT0EsUUFBTVEsVUFBVSxHQUFHaEIscUJBQU9DLE1BQVAsQ0FBYztBQUMvQkMsSUFBQUEsV0FBVyxFQUFFRixxQkFBT0csS0FBUCxDQUFhSCxxQkFBT0ksTUFBUCxFQUFiLENBRGtCO0FBRS9CYSxJQUFBQSxtQkFBbUIsRUFBRWpCLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWYsRUFBZ0M7QUFBRUksTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQWhDLENBRlU7QUFHL0JVLElBQUFBLGtCQUFrQixFQUFFbEIscUJBQU9PLE9BQVAsQ0FBZVAscUJBQU9VLEdBQVAsRUFBZixFQUE2QjtBQUFFRixNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBN0IsQ0FIVztBQUkvQlcsSUFBQUEsaUJBQWlCLEVBQUVuQixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT1UsR0FBUCxFQUFmLEVBQTZCO0FBQUVGLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUE3QjtBQUpZLEdBQWQsQ0FBbkI7O0FBT0EsUUFBTVksWUFBWSxHQUFHcEIscUJBQU9DLE1BQVAsQ0FBYztBQUNqQ0MsSUFBQUEsV0FBVyxFQUFFRixxQkFBT0ksTUFBUDtBQURvQixHQUFkLENBQXJCOztBQUlBLFFBQU1pQixhQUFhLEdBQUdyQixxQkFBT0MsTUFBUCxDQUFjO0FBQ2xDSSxJQUFBQSxRQUFRLEVBQUVMLHFCQUFPSSxNQUFQLEVBRHdCO0FBRWxDa0IsSUFBQUEsZ0JBQWdCLEVBQUV0QixxQkFBT0ksTUFBUDtBQUZnQixHQUFkLENBQXRCOztBQUtBLFFBQU1tQixTQUFjLEdBQUc7QUFDckJDLElBQUFBLGFBQWEsRUFBRXpCLGtCQURNO0FBRXJCMEIsSUFBQUEsWUFBWSxFQUFFZCxpQkFGTztBQUdyQmUsSUFBQUEsWUFBWSxFQUFFYixpQkFITztBQUlyQmMsSUFBQUEsS0FBSyxFQUFFWCxVQUpjO0FBS3JCWSxJQUFBQSxPQUFPLEVBQUVSLFlBTFk7QUFNckJTLElBQUFBLE9BQU8sRUFBRVI7QUFOWSxHQUF2Qjs7QUFTQSxXQUFTUyxtQkFBVCxDQUE2QkMsWUFBN0IsRUFBbURDLFdBQW5ELEVBQTBFO0FBQ3hFLFVBQU1DLFdBQVcsR0FBR1YsU0FBUyxDQUFDUSxZQUFELENBQTdCOztBQUNBLFFBQUksQ0FBQ0UsV0FBTCxFQUFrQjtBQUNoQixZQUFNLElBQUlDLEtBQUosQ0FBVyxvQkFBbUJILFlBQWEsRUFBM0MsQ0FBTjtBQUNEOztBQUNERSxJQUFBQSxXQUFXLENBQUNFLFFBQVosQ0FBcUJILFdBQXJCLEVBTHdFLENBS3JDO0FBQ3BDOztBQUVELFdBQVNJLGdCQUFULENBQTBCTCxZQUExQixFQUFnRDtBQUM5QyxRQUFJLENBQUMsaUNBQW9CQSxZQUFwQixDQUFMLEVBQXdDO0FBQ3RDLGFBQU8sNEJBQVA7QUFDRDtBQUNGO0FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUErSUFqQyxFQUFBQSxNQUFNLENBQUN1QyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixpQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JNLE1BQUFBLE1BQU0sRUFBRXpDLHFCQUFPQyxNQUFQLENBQWM7QUFDcEI4QixRQUFBQSxZQUFZLEVBQUUvQixxQkFBT0ksTUFBUDtBQURNLE9BQWQ7QUFEQTtBQUZaLEdBREYsRUFTRSxPQUNFc0MsT0FERixFQUVFQyxPQUZGLEVBR0VDLFFBSEYsS0FJa0U7QUFDaEUsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixrQ0FBekIsRUFBNkQ7QUFDMUVuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVjtBQUQ2QyxPQUE3RCxDQUFmO0FBR0EsYUFBT2EsUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKQyxVQUFBQSxLQUFLLEVBQUVDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZTixNQUFaLEVBQW9CTyxNQUR2QjtBQUVKQyxVQUFBQSxJQUFJLEVBQUVSO0FBRkY7QUFEVyxPQUFaLENBQVA7QUFNRCxLQVZELENBVUUsT0FBT1MsS0FBUCxFQUFjO0FBQ2RDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQyxJQUFJLENBQUNDLFNBQUwsQ0FBZUosS0FBZixDQUFaO0FBQ0EsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQTlCSDtBQWlDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUVBNUQsRUFBQUEsTUFBTSxDQUFDdUMsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsc0JBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCOEIsUUFBQUEsWUFBWSxFQUFFL0IscUJBQU9JLE1BQVAsRUFETTtBQUVwQjRELFFBQUFBLEVBQUUsRUFBRWhFLHFCQUFPSSxNQUFQO0FBRmdCLE9BQWQ7QUFEQTtBQUZaLEdBREYsRUFVRSxPQUNFc0MsT0FERixFQUVFQyxPQUZGLEVBR0VDLFFBSEYsS0FJa0U7QUFDaEUsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixpQ0FBekIsRUFBNEQ7QUFDekVuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVixZQUQ0QztBQUV6RWlDLFFBQUFBLEVBQUUsRUFBRXJCLE9BQU8sQ0FBQ0YsTUFBUixDQUFldUI7QUFGc0QsT0FBNUQsQ0FBZjtBQUlBLGFBQU9wQixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUFFQyxRQUFBQSxJQUFJLEVBQUVILE1BQU0sQ0FBQ04sT0FBTyxDQUFDRixNQUFSLENBQWV1QixFQUFoQjtBQUFkLE9BQVosQ0FBUDtBQUNELEtBTkQsQ0FNRSxPQUFPTixLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBMUJIO0FBNkJBOzs7O0FBR0E1RCxFQUFBQSxNQUFNLENBQUNtRSxNQUFQLENBQ0U7QUFDRTNCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsc0JBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCOEIsUUFBQUEsWUFBWSxFQUFFL0IscUJBQU9JLE1BQVAsRUFETTtBQUVwQjRELFFBQUFBLEVBQUUsRUFBRWhFLHFCQUFPSSxNQUFQLENBQWM7QUFDaEI4RCxVQUFBQSxTQUFTLEVBQUU7QUFESyxTQUFkO0FBRmdCLE9BQWQ7QUFEQTtBQUZaLEdBREYsRUFZRSxPQUNFeEIsT0FERixFQUVFQyxPQUZGLEVBR0VDLFFBSEYsS0FJa0U7QUFDaEUsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixvQ0FBekIsRUFBK0Q7QUFDNUVuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVixZQUQrQztBQUU1RWlDLFFBQUFBLEVBQUUsRUFBRXJCLE9BQU8sQ0FBQ0YsTUFBUixDQUFldUI7QUFGeUQsT0FBL0QsQ0FBZjtBQUlBLGFBQU9wQixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQ0plLFVBQUFBLE9BQU8sRUFBRWxCLE1BQU0sQ0FBQ2tCO0FBRFo7QUFEVyxPQUFaLENBQVA7QUFLRCxLQVZELENBVUUsT0FBT1QsS0FBUCxFQUFjO0FBQ2QsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQWhDSDtBQW1DQTs7Ozs7Ozs7Ozs7QUFVQTVELEVBQUFBLE1BQU0sQ0FBQ3NFLElBQVAsQ0FDRTtBQUNFOUIsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixpQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JNLE1BQUFBLE1BQU0sRUFBRXpDLHFCQUFPQyxNQUFQLENBQWM7QUFDcEI4QixRQUFBQSxZQUFZLEVBQUUvQixxQkFBT0ksTUFBUDtBQURNLE9BQWQsQ0FEQTtBQUlSZ0QsTUFBQUEsSUFBSSxFQUFFcEQscUJBQU9VLEdBQVA7QUFKRTtBQUZaLEdBREYsRUFVRSxPQUNFZ0MsT0FERixFQUVFQyxPQUZGLEVBR0VDLFFBSEYsS0FJa0U7QUFDaEUsUUFBSTtBQUNGZCxNQUFBQSxtQkFBbUIsQ0FBQ2EsT0FBTyxDQUFDRixNQUFSLENBQWVWLFlBQWhCLEVBQThCWSxPQUFPLENBQUNTLElBQXRDLENBQW5CO0FBQ0QsS0FGRCxDQUVFLE9BQU9NLEtBQVAsRUFBYztBQUNkLGFBQU9kLFFBQVEsQ0FBQ3lCLFVBQVQsQ0FBb0I7QUFBRWpCLFFBQUFBLElBQUksRUFBRU07QUFBUixPQUFwQixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTWIsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QiwyQ0FBekIsRUFBc0U7QUFDbkZuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVixZQURzRDtBQUVuRnFCLFFBQUFBLElBQUksRUFBRVQsT0FBTyxDQUFDUztBQUZxRSxPQUF0RSxDQUFmO0FBSUEsYUFBT1IsUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKZSxVQUFBQSxPQUFPLEVBQUVsQixNQUFNLENBQUNrQjtBQURaO0FBRFcsT0FBWixDQUFQO0FBS0QsS0FWRCxDQVVFLE9BQU9ULEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0FuQ0g7QUFzQ0E7Ozs7QUFHQTVELEVBQUFBLE1BQU0sQ0FBQ3NFLElBQVAsQ0FDRTtBQUNFOUIsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixzQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JNLE1BQUFBLE1BQU0sRUFBRXpDLHFCQUFPQyxNQUFQLENBQWM7QUFDcEI4QixRQUFBQSxZQUFZLEVBQUUvQixxQkFBT0ksTUFBUCxFQURNO0FBRXBCNEQsUUFBQUEsRUFBRSxFQUFFaEUscUJBQU9JLE1BQVAsQ0FBYztBQUNoQitCLFVBQUFBLFFBQVEsRUFBRUM7QUFETSxTQUFkO0FBRmdCLE9BQWQsQ0FEQTtBQU9SZ0IsTUFBQUEsSUFBSSxFQUFFcEQscUJBQU9VLEdBQVA7QUFQRTtBQUZaLEdBREYsRUFhRSxPQUNFZ0MsT0FERixFQUVFQyxPQUZGLEVBR0VDLFFBSEYsS0FJa0U7QUFDaEUsUUFBSTtBQUNGZCxNQUFBQSxtQkFBbUIsQ0FBQ2EsT0FBTyxDQUFDRixNQUFSLENBQWVWLFlBQWhCLEVBQThCWSxPQUFPLENBQUNTLElBQXRDLENBQW5CO0FBQ0QsS0FGRCxDQUVFLE9BQU9NLEtBQVAsRUFBYztBQUNkLGFBQU9kLFFBQVEsQ0FBQ3lCLFVBQVQsQ0FBb0I7QUFBRWpCLFFBQUFBLElBQUksRUFBRU07QUFBUixPQUFwQixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTWIsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixrQ0FBekIsRUFBNkQ7QUFDMUVuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVixZQUQ2QztBQUUxRWlDLFFBQUFBLEVBQUUsRUFBRXJCLE9BQU8sQ0FBQ0YsTUFBUixDQUFldUIsRUFGdUQ7QUFHMUVaLFFBQUFBLElBQUksRUFBRVQsT0FBTyxDQUFDUztBQUg0RCxPQUE3RCxDQUFmO0FBS0EsYUFBT1IsUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKZSxVQUFBQSxPQUFPLEVBQUVsQixNQUFNLENBQUNrQjtBQURaO0FBRFcsT0FBWixDQUFQO0FBS0QsS0FYRCxDQVdFLE9BQU9ULEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0F2Q0g7QUEwQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF3QkE1RCxFQUFBQSxNQUFNLENBQUN1QyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLGdCQUR0QjtBQUVFSixJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FDRU8sT0FERixFQUVFQyxPQUZGLEVBR0VDLFFBSEYsS0FJa0U7QUFDaEUsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5Qiw4QkFBekIsQ0FBZjtBQUVBLGFBQU9OLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUVIO0FBRFcsT0FBWixDQUFQO0FBR0QsS0FORCxDQU1FLE9BQU9TLEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0FyQkg7QUF3QkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdURBNUQsRUFBQUEsTUFBTSxDQUFDdUMsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxzQkFEdEI7QUFFRUosSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQUtFLE9BQ0VPLE9BREYsRUFFRUMsT0FGRixFQUdFQyxRQUhGLEtBSWtFO0FBQ2hFLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7QUFFQSxRQUFJTSxNQUFKOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsTUFBTSxHQUFHLE1BQU1KLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsOEJBQXpCLENBQWY7QUFFQSxhQUFPTixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFSDtBQURXLE9BQVosQ0FBUDtBQUdELEtBTkQsQ0FNRSxPQUFPUyxLQUFQLEVBQWM7QUFDZCxhQUFPZCxRQUFRLENBQUMwQixNQUFULENBQWdCO0FBQ3JCQyxRQUFBQSxVQUFVLEVBQUViLEtBQUssQ0FBQ2EsVUFERztBQUVyQm5CLFFBQUFBLElBQUksRUFBRW9CLG9CQUFvQixDQUFDZCxLQUFEO0FBRkwsT0FBaEIsQ0FBUDtBQUlEO0FBQ0YsR0F6Qkg7QUE0QkE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdURBNUQsRUFBQUEsTUFBTSxDQUFDc0UsSUFBUCxDQUNFO0FBQ0U5QixJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsNkJBRHRCO0FBRUVKLElBQUFBLFFBQVEsRUFBRTtBQUNSaUIsTUFBQUEsSUFBSSxFQUFFcEQscUJBQU9VLEdBQVA7QUFERTtBQUZaLEdBREYsRUFPRSxPQUFPZ0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7QUFDQSxRQUFJTSxNQUFKOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsTUFBTSxHQUFHLE1BQU1KLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsK0JBQXpCLEVBQTBEO0FBQ3ZFRSxRQUFBQSxJQUFJLEVBQUVULE9BQU8sQ0FBQ1M7QUFEeUQsT0FBMUQsQ0FBZjtBQUdBLGFBQU9SLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUU7QUFDSmUsVUFBQUEsT0FBTyxFQUFFbEIsTUFBTSxDQUFDa0I7QUFEWjtBQURXLE9BQVosQ0FBUDtBQUtELEtBVEQsQ0FTRSxPQUFPVCxLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBdEJIO0FBeUJBOzs7Ozs7QUFLQTVELEVBQUFBLE1BQU0sQ0FBQ21FLE1BQVAsQ0FDRTtBQUNFM0IsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLHNCQUR0QjtBQUVFSixJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT08sT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7QUFDQSxRQUFJOEIsVUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLFVBQVUsR0FBRyxNQUFNNUIsTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixnQ0FBekIsQ0FBbkI7QUFDQSxhQUFPTixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQ0plLFVBQUFBLE9BQU8sRUFBRU0sVUFBVSxDQUFDTjtBQURoQjtBQURXLE9BQVosQ0FBUDtBQUtELEtBUEQsQ0FPRSxPQUFPVCxLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBbEJIO0FBcUJBOzs7Ozs7Ozs7Ozs7QUFXQTVELEVBQUFBLE1BQU0sQ0FBQ3VDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsY0FEdEI7QUFFRUosSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQUtFLE9BQU9PLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmOztBQUNBLFFBQUk7QUFDRixZQUFNOEIsVUFBVSxHQUFHLE1BQU01QixNQUFNLENBQUNLLGlCQUFQLENBQXlCLGlDQUF6QixDQUF6QjtBQUNBLGFBQU9OLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUVxQjtBQURXLE9BQVosQ0FBUDtBQUdELEtBTEQsQ0FLRSxPQUFPZixLQUFQLEVBQWM7QUFDZCxhQUFPZCxRQUFRLENBQUN5QixVQUFULENBQW9CO0FBQ3pCakIsUUFBQUEsSUFBSSxFQUFFTTtBQURtQixPQUFwQixDQUFQO0FBR0Q7QUFDRixHQWpCSDtBQW9CQTs7Ozs7O0FBS0E1RCxFQUFBQSxNQUFNLENBQUNzRSxJQUFQLENBQ0U7QUFDRTlCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsMEJBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCO0FBQ0F5RSxRQUFBQSxTQUFTLEVBQUUxRSxxQkFBT0csS0FBUCxDQUFhSCxxQkFBT0ksTUFBUCxFQUFiO0FBRlMsT0FBZCxDQURBO0FBS1JnRCxNQUFBQSxJQUFJLEVBQUVwRCxxQkFBT1UsR0FBUDtBQUxFO0FBRlosR0FERixFQVdFLE9BQU9nQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjs7QUFDQSxRQUFJO0FBQ0YsWUFBTThCLFVBQVUsR0FBRyxNQUFNNUIsTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixpQ0FBekIsRUFBNEQ7QUFDbkZFLFFBQUFBLElBQUksRUFBRVQsT0FBTyxDQUFDUztBQURxRSxPQUE1RCxDQUF6QjtBQUdBLGFBQU9SLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUVxQjtBQURXLE9BQVosQ0FBUDtBQUdELEtBUEQsQ0FPRSxPQUFPZixLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBdkJIO0FBMEJBOzs7Ozs7O0FBTUE1RCxFQUFBQSxNQUFNLENBQUNzRSxJQUFQLENBQ0U7QUFDRTlCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsaUJBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSaUIsTUFBQUEsSUFBSSxFQUFFcEQscUJBQU9DLE1BQVAsQ0FBYztBQUNsQjBFLFFBQUFBLEtBQUssRUFBRTNFLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPSSxNQUFQLEVBQWY7QUFEVyxPQUFkO0FBREU7QUFGWixHQURGLEVBU0UsT0FBT3NDLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmOztBQUNBLFFBQUk7QUFDRixZQUFNOEIsVUFBVSxHQUFHLE1BQU01QixNQUFNLENBQUNLLGlCQUFQLENBQXlCLHNDQUF6QixFQUFpRTtBQUN4RnlCLFFBQUFBLEtBQUssRUFBRWhDLE9BQU8sQ0FBQ1MsSUFBUixDQUFhdUIsS0FBYixDQUFtQkMsSUFBbkIsQ0FBd0IsR0FBeEIsQ0FEaUY7QUFFeEZDLFFBQUFBLGtCQUFrQixFQUFFLElBRm9FO0FBR3hGQyxRQUFBQSxnQkFBZ0IsRUFBRTtBQUhzRSxPQUFqRSxDQUF6QjtBQU1BLGFBQU9sQyxRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFcUI7QUFEVyxPQUFaLENBQVA7QUFHRCxLQVZELENBVUUsT0FBT2YsS0FBUCxFQUFjO0FBQ2QsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQXhCSDtBQTJCQTs7Ozs7OztBQU1BNUQsRUFBQUEsTUFBTSxDQUFDdUMsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsVUFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBRlosR0FERixFQUtFLE9BQU9PLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmOztBQUNBLFFBQUk7QUFDRixZQUFNOEIsVUFBVSxHQUFHLE1BQU01QixNQUFNLENBQUNLLGlCQUFQLENBQXlCLDZCQUF6QixDQUF6QjtBQUNBLGFBQU9OLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUVxQjtBQURXLE9BQVosQ0FBUDtBQUdELEtBTEQsQ0FLRSxPQUFPZixLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBZkg7QUFpQkQ7O0FBRUQsU0FBU2Msb0JBQVQsQ0FBOEJkLEtBQTlCLEVBQTBDO0FBQ3hDLE1BQUlBLEtBQUssQ0FBQ2QsUUFBVixFQUFvQjtBQUNsQixRQUFJO0FBQ0YsWUFBTW1DLGVBQWUsR0FBR2xCLElBQUksQ0FBQ21CLEtBQUwsQ0FBV3RCLEtBQUssQ0FBQ2QsUUFBakIsQ0FBeEI7QUFDQSxhQUFPbUMsZUFBZSxDQUFDRSxNQUFoQixJQUEwQnZCLEtBQUssQ0FBQ2QsUUFBdkM7QUFDRCxLQUhELENBR0UsT0FBT3NDLFlBQVAsRUFBcUI7QUFDckIsYUFBT3hCLEtBQUssQ0FBQ2QsUUFBYjtBQUNEO0FBQ0Y7O0FBQ0QsU0FBT2MsS0FBSyxDQUFDUyxPQUFiO0FBQ0Q7O0FBRUQsU0FBU0osYUFBVCxDQUF1Qm5CLFFBQXZCLEVBQXNFYyxLQUF0RSxFQUFrRjtBQUNoRixTQUFPZCxRQUFRLENBQUMwQixNQUFULENBQWdCO0FBQ3JCQyxJQUFBQSxVQUFVLEVBQUViLEtBQUssQ0FBQ2EsVUFERztBQUVyQm5CLElBQUFBLElBQUksRUFBRW9CLG9CQUFvQixDQUFDZCxLQUFEO0FBRkwsR0FBaEIsQ0FBUDtBQUlEIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqICAgQ29weXJpZ2h0IDIwMjAgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiAgIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIikuXG4gKiAgIFlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqICAgQSBjb3B5IG9mIHRoZSBMaWNlbnNlIGlzIGxvY2F0ZWQgYXRcbiAqXG4gKiAgICAgICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiAgIG9yIGluIHRoZSBcImxpY2Vuc2VcIiBmaWxlIGFjY29tcGFueWluZyB0aGlzIGZpbGUuIFRoaXMgZmlsZSBpcyBkaXN0cmlidXRlZFxuICogICBvbiBhbiBcIkFTIElTXCIgQkFTSVMsIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXJcbiAqICAgZXhwcmVzcyBvciBpbXBsaWVkLiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmdcbiAqICAgcGVybWlzc2lvbnMgYW5kIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQge1xuICBJUm91dGVyLFxuICBSZXNwb25zZUVycm9yLFxuICBJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZSxcbiAgT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksXG59IGZyb20gJ29wZW5zZWFyY2gtZGFzaGJvYXJkcy9zZXJ2ZXInO1xuaW1wb3J0IHsgQVBJX1BSRUZJWCwgQ09ORklHVVJBVElPTl9BUElfUFJFRklYLCBpc1ZhbGlkUmVzb3VyY2VOYW1lIH0gZnJvbSAnLi4vLi4vY29tbW9uJztcblxuLy8gVE9ETzogY29uc2lkZXIgdG8gZXh0cmFjdCBlbnRpdHkgQ1JVRCBvcGVyYXRpb25zIGFuZCBwdXQgaXQgaW50byBhIGNsaWVudCBjbGFzc1xuZXhwb3J0IGZ1bmN0aW9uIGRlZmluZVJvdXRlcyhyb3V0ZXI6IElSb3V0ZXIpIHtcbiAgY29uc3QgaW50ZXJuYWxVc2VyU2NoZW1hID0gc2NoZW1hLm9iamVjdCh7XG4gICAgZGVzY3JpcHRpb246IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgIHBhc3N3b3JkOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBiYWNrZW5kX3JvbGVzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcbiAgICBhdHRyaWJ1dGVzOiBzY2hlbWEuYW55KHsgZGVmYXVsdFZhbHVlOiB7fSB9KSxcbiAgfSk7XG5cbiAgY29uc3QgYWN0aW9uR3JvdXBTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBkZXNjcmlwdGlvbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgYWxsb3dlZF9hY3Rpb25zOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCkpLFxuICAgIC8vIHR5cGUgZmllbGQgaXMgbm90IHN1cHBvcnRlZCBpbiBsZWdhY3kgaW1wbGVtZW50YXRpb24sIGNvbW1lbnQgaXQgb3V0IGZvciBub3cuXG4gICAgLy8gdHlwZTogc2NoZW1hLm9uZU9mKFtcbiAgICAvLyAgIHNjaGVtYS5saXRlcmFsKCdjbHVzdGVyJyksXG4gICAgLy8gICBzY2hlbWEubGl0ZXJhbCgnaW5kZXgnKSxcbiAgICAvLyAgIHNjaGVtYS5saXRlcmFsKCdvcGVuc2VhcmNoX2Rhc2hib2FyZHMnKSxcbiAgICAvLyBdKSxcbiAgfSk7XG5cbiAgY29uc3Qgcm9sZU1hcHBpbmdTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBkZXNjcmlwdGlvbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgYmFja2VuZF9yb2xlczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXG4gICAgaG9zdHM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxuICAgIHVzZXJzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcbiAgfSk7XG5cbiAgY29uc3Qgcm9sZVNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICAgIGRlc2NyaXB0aW9uOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBjbHVzdGVyX3Blcm1pc3Npb25zOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcbiAgICB0ZW5hbnRfcGVybWlzc2lvbnM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5hbnkoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxuICAgIGluZGV4X3Blcm1pc3Npb25zOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuYW55KCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcbiAgfSk7XG5cbiAgY29uc3QgdGVuYW50U2NoZW1hID0gc2NoZW1hLm9iamVjdCh7XG4gICAgZGVzY3JpcHRpb246IHNjaGVtYS5zdHJpbmcoKSxcbiAgfSk7XG5cbiAgY29uc3QgYWNjb3VudFNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICAgIHBhc3N3b3JkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgY3VycmVudF9wYXNzd29yZDogc2NoZW1hLnN0cmluZygpLFxuICB9KTtcblxuICBjb25zdCBzY2hlbWFNYXA6IGFueSA9IHtcbiAgICBpbnRlcm5hbHVzZXJzOiBpbnRlcm5hbFVzZXJTY2hlbWEsXG4gICAgYWN0aW9uZ3JvdXBzOiBhY3Rpb25Hcm91cFNjaGVtYSxcbiAgICByb2xlc21hcHBpbmc6IHJvbGVNYXBwaW5nU2NoZW1hLFxuICAgIHJvbGVzOiByb2xlU2NoZW1hLFxuICAgIHRlbmFudHM6IHRlbmFudFNjaGVtYSxcbiAgICBhY2NvdW50OiBhY2NvdW50U2NoZW1hLFxuICB9O1xuXG4gIGZ1bmN0aW9uIHZhbGlkYXRlUmVxdWVzdEJvZHkocmVzb3VyY2VOYW1lOiBzdHJpbmcsIHJlcXVlc3RCb2R5OiBhbnkpOiBhbnkge1xuICAgIGNvbnN0IGlucHV0U2NoZW1hID0gc2NoZW1hTWFwW3Jlc291cmNlTmFtZV07XG4gICAgaWYgKCFpbnB1dFNjaGVtYSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIHJlc291cmNlICR7cmVzb3VyY2VOYW1lfWApO1xuICAgIH1cbiAgICBpbnB1dFNjaGVtYS52YWxpZGF0ZShyZXF1ZXN0Qm9keSk7IC8vIHRocm93cyBlcnJvciBpZiB2YWxpZGF0aW9uIGZhaWxcbiAgfVxuXG4gIGZ1bmN0aW9uIHZhbGlkYXRlRW50aXR5SWQocmVzb3VyY2VOYW1lOiBzdHJpbmcpIHtcbiAgICBpZiAoIWlzVmFsaWRSZXNvdXJjZU5hbWUocmVzb3VyY2VOYW1lKSkge1xuICAgICAgcmV0dXJuICdJbnZhbGlkIGVudGl0eSBuYW1lIG9yIGlkLic7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIExpc3RzIHJlc291cmNlcyBieSByZXNvdXJjZSBuYW1lLlxuICAgKlxuICAgKiBUaGUgcmVzcG9uc2UgZm9ybWF0IGlzOlxuICAgKiB7XG4gICAqICAgXCJ0b3RhbFwiOiA8dG90YWxfZW50aXR5X2NvdW50PixcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJlbnRpdHlfaWRfMVwiOiB7IDxlbnRpdHlfc3RydWN0dXJlPiB9LFxuICAgKiAgICAgXCJlbnRpdHlfaWRfMlwiOiB7IDxlbnRpdHlfc3RydWN0dXJlPiB9LFxuICAgKiAgICAgLi4uXG4gICAqICAgfVxuICAgKiB9XG4gICAqXG4gICAqIGUuZy4gd2hlbiBsaXN0aW5nIGludGVybmFsIHVzZXJzLCByZXNwb25zZSBtYXkgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJ0b3RhbFwiOiAyLFxuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcImFwaV90ZXN0X3VzZXIyXCI6IHtcbiAgICogICAgICAgXCJoYXNoXCI6IFwiXCIsXG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogZmFsc2UsXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgICAgICBcImJhY2tlbmRfcm9sZXNcIjogW10sXG4gICAqICAgICAgIFwiYXR0cmlidXRlc1wiOiB7fSxcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIlwiLFxuICAgKiAgICAgICBcInN0YXRpY1wiOiBmYWxzZVxuICAgKiAgICAgfSxcbiAgICogICAgIFwiYXBpX3Rlc3RfdXNlcjFcIjoge1xuICAgKiAgICAgICBcImhhc2hcIjogXCJcIixcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiBmYWxzZSxcbiAgICogICAgICAgXCJoaWRkZW5cIjogZmFsc2UsXG4gICAqICAgICAgIFwiYmFja2VuZF9yb2xlc1wiOiBbXSxcbiAgICogICAgICAgXCJhdHRyaWJ1dGVzXCI6IHt9LFxuICAgKiAgICAgICBcInN0YXRpY1wiOiBmYWxzZVxuICAgKiAgICAgfVxuICAgKiB9XG4gICAqXG4gICAqIHdoZW4gbGlzdGluZyBhY3Rpb24gZ3JvdXBzLCByZXNwb25zZSB3aWxsIGxvb2sgbGlrZTpcbiAgICoge1xuICAgKiAgIFwidG90YWxcIjogMixcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJyZWFkXCI6IHtcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiaW5kaWNlczpkYXRhL3JlYWQqXCIsIFwiaW5kaWNlczphZG1pbi9tYXBwaW5ncy9maWVsZHMvZ2V0KlwiXSxcbiAgICogICAgICAgXCJ0eXBlXCI6IFwiaW5kZXhcIixcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIkFsbG93IGFsbCByZWFkIG9wZXJhdGlvbnNcIixcbiAgICogICAgICAgXCJzdGF0aWNcIjogZmFsc2VcbiAgICogICAgIH0sXG4gICAqICAgICBcImNsdXN0ZXJfYWxsXCI6IHtcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiY2x1c3RlcjoqXCJdLFxuICAgKiAgICAgICBcInR5cGVcIjogXCJjbHVzdGVyXCIsXG4gICAqICAgICAgIFwiZGVzY3JpcHRpb25cIjogXCJBbGxvdyBldmVyeXRoaW5nIG9uIGNsdXN0ZXIgbGV2ZWxcIixcbiAgICogICAgICAgXCJzdGF0aWNcIjogZmFsc2VcbiAgICogICAgIH1cbiAgICogfVxuICAgKlxuICAgKiByb2xlOlxuICAgKiB7XG4gICAqICAgXCJ0b3RhbFwiOiAyLFxuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcIm9wZW5zZWFyY2hfZGFzaGJvYXJkc191c2VyXCI6IHtcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIlByb3ZpZGUgdGhlIG1pbmltdW0gcGVybWlzc2lvbnMgZm9yIGEgb3BlbnNlYXJjaF9kYXNoYm9hcmRzIHVzZXJcIixcbiAgICogICAgICAgXCJjbHVzdGVyX3Blcm1pc3Npb25zXCI6IFtcImNsdXN0ZXJfY29tcG9zaXRlX29wc1wiXSxcbiAgICogICAgICAgXCJpbmRleF9wZXJtaXNzaW9uc1wiOiBbe1xuICAgKiAgICAgICAgIFwiaW5kZXhfcGF0dGVybnNcIjogW1wiLm9wZW5zZWFyY2hfZGFzaGJvYXJkc1wiLCBcIi5vcGVuc2VhcmNoX2Rhc2hib2FyZHMtNlwiLCBcIi5vcGVuc2VhcmNoX2Rhc2hib2FyZHNfKlwiXSxcbiAgICogICAgICAgICBcImZsc1wiOiBbXSxcbiAgICogICAgICAgICBcIm1hc2tlZF9maWVsZHNcIjogW10sXG4gICAqICAgICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wicmVhZFwiLCBcImRlbGV0ZVwiLCBcIm1hbmFnZVwiLCBcImluZGV4XCJdXG4gICAqICAgICAgIH0sIHtcbiAgICogICAgICAgICBcImluZGV4X3BhdHRlcm5zXCI6IFtcIi50YXNrc1wiLCBcIi5tYW5hZ2VtZW50LWJlYXRzXCJdLFxuICAgKiAgICAgICAgIFwiZmxzXCI6IFtdLFxuICAgKiAgICAgICAgIFwibWFza2VkX2ZpZWxkc1wiOiBbXSxcbiAgICogICAgICAgICBcImFsbG93ZWRfYWN0aW9uc1wiOiBbXCJpbmRpY2VzX2FsbFwiXVxuICAgKiAgICAgICB9XSxcbiAgICogICAgICAgXCJ0ZW5hbnRfcGVybWlzc2lvbnNcIjogW10sXG4gICAqICAgICAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJhbGxfYWNjZXNzXCI6IHtcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIkFsbG93IGZ1bGwgYWNjZXNzIHRvIGFsbCBpbmRpY2VzIGFuZCBhbGwgY2x1c3RlciBBUElzXCIsXG4gICAqICAgICAgIFwiY2x1c3Rlcl9wZXJtaXNzaW9uc1wiOiBbXCIqXCJdLFxuICAgKiAgICAgICBcImluZGV4X3Blcm1pc3Npb25zXCI6IFt7XG4gICAqICAgICAgICAgXCJpbmRleF9wYXR0ZXJuc1wiOiBbXCIqXCJdLFxuICAgKiAgICAgICAgIFwiZmxzXCI6IFtdLFxuICAgKiAgICAgICAgIFwibWFza2VkX2ZpZWxkc1wiOiBbXSxcbiAgICogICAgICAgICBcImFsbG93ZWRfYWN0aW9uc1wiOiBbXCIqXCJdXG4gICAqICAgICAgIH1dLFxuICAgKiAgICAgICBcInRlbmFudF9wZXJtaXNzaW9uc1wiOiBbe1xuICAgKiAgICAgICAgIFwidGVuYW50X3BhdHRlcm5zXCI6IFtcIipcIl0sXG4gICAqICAgICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wib3BlbnNlYXJjaF9kYXNoYm9hcmRzX2FsbF93cml0ZVwiXVxuICAgKiAgICAgICB9XSxcbiAgICogICAgICAgXCJzdGF0aWNcIjogZmFsc2VcbiAgICogICAgIH1cbiAgICogICB9XG4gICAqIH1cbiAgICpcbiAgICogcm9sZXNtYXBwaW5nOlxuICAgKiB7XG4gICAqICAgXCJ0b3RhbFwiOiAyLFxuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcInNlY3VyaXR5X21hbmFnZXJcIjoge1xuICAgKiAgICAgICBcInJlc2VydmVkXCI6IGZhbHNlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJiYWNrZW5kX3JvbGVzXCI6IFtdLFxuICAgKiAgICAgICBcImhvc3RzXCI6IFtdLFxuICAgKiAgICAgICBcInVzZXJzXCI6IFtcInplbmd5YW5cIiwgXCJhZG1pblwiXSxcbiAgICogICAgICAgXCJhbmRfYmFja2VuZF9yb2xlc1wiOiBbXVxuICAgKiAgICAgfSxcbiAgICogICAgIFwiYWxsX2FjY2Vzc1wiOiB7XG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogZmFsc2UsXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgICAgICBcImJhY2tlbmRfcm9sZXNcIjogW10sXG4gICAqICAgICAgIFwiaG9zdHNcIjogW10sXG4gICAqICAgICAgIFwidXNlcnNcIjogW1wiemVuZ3lhblwiLCBcImFkbWluXCIsIFwiaW5kZXh0ZXN0XCJdLFxuICAgKiAgICAgICBcImFuZF9iYWNrZW5kX3JvbGVzXCI6IFtdXG4gICAqICAgICB9XG4gICAqICAgfVxuICAgKiB9XG4gICAqXG4gICAqIHRlbmFudHM6XG4gICAqIHtcbiAgICogICBcInRvdGFsXCI6IDIsXG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwiZ2xvYmFsX3RlbmFudFwiOiB7XG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogdHJ1ZSxcbiAgICogICAgICAgXCJoaWRkZW5cIjogZmFsc2UsXG4gICAqICAgICAgIFwiZGVzY3JpcHRpb25cIjogXCJHbG9iYWwgdGVuYW50XCIsXG4gICAqICAgICAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJ0ZXN0IHRlbmFudFwiOiB7XG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogZmFsc2UsXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgICAgICBcImRlc2NyaXB0aW9uXCI6IFwidGVuYW50IGRlc2NyaXB0aW9uXCIsXG4gICAqICAgICAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqICAgICB9XG4gICAqICAgfVxuICAgKiB9XG4gICAqL1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0FQSV9QUkVGSVh9LyR7Q09ORklHVVJBVElPTl9BUElfUFJFRklYfS97cmVzb3VyY2VOYW1lfWAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHJlc291cmNlTmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoXG4gICAgICBjb250ZXh0LFxuICAgICAgcmVxdWVzdCxcbiAgICAgIHJlc3BvbnNlXG4gICAgKTogUHJvbWlzZTxJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxhbnkgfCBSZXNwb25zZUVycm9yPj4gPT4ge1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBsZXQgZXNSZXNwO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5Lmxpc3RSZXNvdXJjZScsIHtcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHJlcXVlc3QucGFyYW1zLnJlc291cmNlTmFtZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGVzUmVzcCkubGVuZ3RoLFxuICAgICAgICAgICAgZGF0YTogZXNSZXNwLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZXJyb3IpKTtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIEdldHMgZW50aXR5IGJ5IGlkLlxuICAgKlxuICAgKiB0aGUgcmVzcG9uc2UgZm9ybWF0IGRpZmZlcnMgZnJvbSBkaWZmZXJlbnQgcmVzb3VyY2UgdHlwZXMuIGUuZy5cbiAgICpcbiAgICogZm9yIGludGVybmFsIHVzZXIsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJoYXNoXCI6IFwiXCIsXG4gICAqICAgXCJyZXNlcnZlZFwiOiBmYWxzZSxcbiAgICogICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICBcImJhY2tlbmRfcm9sZXNcIjogW10sXG4gICAqICAgXCJhdHRyaWJ1dGVzXCI6IHt9LFxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqIH1cbiAgICpcbiAgICogZm9yIHJvbGUsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgIFwiZGVzY3JpcHRpb25cIjogXCJBbGxvdyBmdWxsIGFjY2VzcyB0byBhbGwgaW5kaWNlcyBhbmQgYWxsIGNsdXN0ZXIgQVBJc1wiLFxuICAgKiAgIFwiY2x1c3Rlcl9wZXJtaXNzaW9uc1wiOiBbXCIqXCJdLFxuICAgKiAgIFwiaW5kZXhfcGVybWlzc2lvbnNcIjogW3tcbiAgICogICAgIFwiaW5kZXhfcGF0dGVybnNcIjogW1wiKlwiXSxcbiAgICogICAgIFwiZmxzXCI6IFtdLFxuICAgKiAgICAgXCJtYXNrZWRfZmllbGRzXCI6IFtdLFxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiKlwiXVxuICAgKiAgIH1dLFxuICAgKiAgIFwidGVuYW50X3Blcm1pc3Npb25zXCI6IFt7XG4gICAqICAgICBcInRlbmFudF9wYXR0ZXJuc1wiOiBbXCIqXCJdLFxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wib3BlbnNlYXJjaF9kYXNoYm9hcmRzX2FsbF93cml0ZVwiXVxuICAgKiAgIH1dLFxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqIH1cbiAgICpcbiAgICogZm9yIHJvbGVzIG1hcHBpbmcsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgIFwiZGVzY3JpcHRpb25cIjogXCJBbGxvdyBmdWxsIGFjY2VzcyB0byBhbGwgaW5kaWNlcyBhbmQgYWxsIGNsdXN0ZXIgQVBJc1wiLFxuICAgKiAgIFwiY2x1c3Rlcl9wZXJtaXNzaW9uc1wiOiBbXCIqXCJdLFxuICAgKiAgIFwiaW5kZXhfcGVybWlzc2lvbnNcIjogW3tcbiAgICogICAgIFwiaW5kZXhfcGF0dGVybnNcIjogW1wiKlwiXSxcbiAgICogICAgIFwiZmxzXCI6IFtdLFxuICAgKiAgICAgXCJtYXNrZWRfZmllbGRzXCI6IFtdLFxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiKlwiXVxuICAgKiAgIH1dLFxuICAgKiAgIFwidGVuYW50X3Blcm1pc3Npb25zXCI6IFt7XG4gICAqICAgICBcInRlbmFudF9wYXR0ZXJuc1wiOiBbXCIqXCJdLFxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wib3BlbnNlYXJjaF9kYXNoYm9hcmRzX2FsbF93cml0ZVwiXVxuICAgKiAgIH1dLFxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqIH1cbiAgICpcbiAgICogZm9yIGFjdGlvbiBncm91cHMsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgIFwiYWxsb3dlZF9hY3Rpb25zXCI6IFtcImluZGljZXM6ZGF0YS9yZWFkKlwiLCBcImluZGljZXM6YWRtaW4vbWFwcGluZ3MvZmllbGRzL2dldCpcIl0sXG4gICAqICAgXCJ0eXBlXCI6IFwiaW5kZXhcIixcbiAgICogICBcImRlc2NyaXB0aW9uXCI6IFwiQWxsb3cgYWxsIHJlYWQgb3BlcmF0aW9uc1wiLFxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqIH1cbiAgICpcbiAgICogZm9yIHRlbmFudCwgcmVzcG9uc2Ugd2lsbCBsb29rIGxpa2U6XG4gICAqIHtcbiAgICogICBcInJlc2VydmVkXCI6IHRydWUsXG4gICAqICAgXCJoaWRkZW5cIjogZmFsc2UsXG4gICAqICAgXCJkZXNjcmlwdGlvblwiOiBcIkdsb2JhbCB0ZW5hbnRcIixcbiAgICogICBcInN0YXRpY1wiOiBmYWxzZVxuICAgKiB9LFxuICAgKi9cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0ve3Jlc291cmNlTmFtZX0ve2lkfWAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHJlc291cmNlTmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChcbiAgICAgIGNvbnRleHQsXG4gICAgICByZXF1ZXN0LFxuICAgICAgcmVzcG9uc2VcbiAgICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuZ2V0UmVzb3VyY2UnLCB7XG4gICAgICAgICAgcmVzb3VyY2VOYW1lOiByZXF1ZXN0LnBhcmFtcy5yZXNvdXJjZU5hbWUsXG4gICAgICAgICAgaWQ6IHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogZXNSZXNwW3JlcXVlc3QucGFyYW1zLmlkXSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBEZWxldGVzIGFuIGVudGl0eSBieSBpZC5cbiAgICovXG4gIHJvdXRlci5kZWxldGUoXG4gICAge1xuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vJHtDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVh9L3tyZXNvdXJjZU5hbWV9L3tpZH1gLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZyh7XG4gICAgICAgICAgICBtaW5MZW5ndGg6IDEsXG4gICAgICAgICAgfSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChcbiAgICAgIGNvbnRleHQsXG4gICAgICByZXF1ZXN0LFxuICAgICAgcmVzcG9uc2VcbiAgICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuZGVsZXRlUmVzb3VyY2UnLCB7XG4gICAgICAgICAgcmVzb3VyY2VOYW1lOiByZXF1ZXN0LnBhcmFtcy5yZXNvdXJjZU5hbWUsXG4gICAgICAgICAgaWQ6IHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBtZXNzYWdlOiBlc1Jlc3AubWVzc2FnZSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBVcGRhdGUgb2JqZWN0IHdpdGggb3V0IElkLiBSZXNvdXJjZSBpZGVudGlmaWNhdGlvbiBpcyBleHBlY3RlZCB0byBjb21wdXRlZCBmcm9tIGhlYWRlcnMuIEVnOiBhdXRoIGhlYWRlcnNcbiAgICpcbiAgICogUmVxdWVzdCBzYW1wbGU6XG4gICAqIC9jb25maWd1cmF0aW9uL2FjY291bnRcbiAgICoge1xuICAgKiAgIFwicGFzc3dvcmRcIjogXCJuZXctcGFzc3dvcmRcIixcbiAgICogICBcImN1cnJlbnRfcGFzc3dvcmRcIjogXCJvbGQtcGFzc3dvcmRcIlxuICAgKiB9XG4gICAqL1xuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0ve3Jlc291cmNlTmFtZX1gLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoXG4gICAgICBjb250ZXh0LFxuICAgICAgcmVxdWVzdCxcbiAgICAgIHJlc3BvbnNlXG4gICAgKTogUHJvbWlzZTxJT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZTxhbnkgfCBSZXNwb25zZUVycm9yPj4gPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdmFsaWRhdGVSZXF1ZXN0Qm9keShyZXF1ZXN0LnBhcmFtcy5yZXNvdXJjZU5hbWUsIHJlcXVlc3QuYm9keSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmFkUmVxdWVzdCh7IGJvZHk6IGVycm9yIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBsZXQgZXNSZXNwO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LnNhdmVSZXNvdXJjZVdpdGhvdXRJZCcsIHtcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHJlcXVlc3QucGFyYW1zLnJlc291cmNlTmFtZSxcbiAgICAgICAgICBib2R5OiByZXF1ZXN0LmJvZHksXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcC5tZXNzYWdlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSBlbnRpdHkgYnkgSWQuXG4gICAqL1xuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0ve3Jlc291cmNlTmFtZX0ve2lkfWAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHJlc291cmNlTmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKHtcbiAgICAgICAgICAgIHZhbGlkYXRlOiB2YWxpZGF0ZUVudGl0eUlkLFxuICAgICAgICAgIH0pLFxuICAgICAgICB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChcbiAgICAgIGNvbnRleHQsXG4gICAgICByZXF1ZXN0LFxuICAgICAgcmVzcG9uc2VcbiAgICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICB2YWxpZGF0ZVJlcXVlc3RCb2R5KHJlcXVlc3QucGFyYW1zLnJlc291cmNlTmFtZSwgcmVxdWVzdC5ib2R5KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5iYWRSZXF1ZXN0KHsgYm9keTogZXJyb3IgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuc2F2ZVJlc291cmNlJywge1xuICAgICAgICAgIHJlc291cmNlTmFtZTogcmVxdWVzdC5wYXJhbXMucmVzb3VyY2VOYW1lLFxuICAgICAgICAgIGlkOiByZXF1ZXN0LnBhcmFtcy5pZCxcbiAgICAgICAgICBib2R5OiByZXF1ZXN0LmJvZHksXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcC5tZXNzYWdlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIEdldHMgYXV0aGVudGljYXRpb24gaW5mbyBvZiB0aGUgdXNlci5cbiAgICpcbiAgICogVGhlIHJlc3BvbnNlIGxvb2tzIGxpa2U6XG4gICAqIHtcbiAgICogICBcInVzZXJcIjogXCJVc2VyIFtuYW1lPWFkbWluLCByb2xlcz1bXSwgcmVxdWVzdGVkVGVuYW50PV9fdXNlcl9fXVwiLFxuICAgKiAgIFwidXNlcl9uYW1lXCI6IFwiYWRtaW5cIixcbiAgICogICBcInVzZXJfcmVxdWVzdGVkX3RlbmFudFwiOiBcIl9fdXNlcl9fXCIsXG4gICAqICAgXCJyZW1vdGVfYWRkcmVzc1wiOiBcIjEyNy4wLjAuMTozNTA0NFwiLFxuICAgKiAgIFwiYmFja2VuZF9yb2xlc1wiOiBbXSxcbiAgICogICBcImN1c3RvbV9hdHRyaWJ1dGVfbmFtZXNcIjogW10sXG4gICAqICAgXCJyb2xlc1wiOiBbXCJhbGxfYWNjZXNzXCIsIFwic2VjdXJpdHlfbWFuYWdlclwiXSxcbiAgICogICBcInRlbmFudHNcIjoge1xuICAgKiAgICAgXCJhbm90aGVyX3RlbmFudFwiOiB0cnVlLFxuICAgKiAgICAgXCJhZG1pblwiOiB0cnVlLFxuICAgKiAgICAgXCJnbG9iYWxfdGVuYW50XCI6IHRydWUsXG4gICAqICAgICBcImFhYWFhXCI6IHRydWUsXG4gICAqICAgICBcInRlc3QgdGVuYW50XCI6IHRydWVcbiAgICogICB9LFxuICAgKiAgIFwicHJpbmNpcGFsXCI6IG51bGwsXG4gICAqICAgXCJwZWVyX2NlcnRpZmljYXRlc1wiOiBcIjBcIixcbiAgICogICBcInNzb19sb2dvdXRfdXJsXCI6IG51bGxcbiAgICogfVxuICAgKi9cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS9hdXRoL2F1dGhpbmZvYCxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuICAgIGFzeW5jIChcbiAgICAgIGNvbnRleHQsXG4gICAgICByZXF1ZXN0LFxuICAgICAgcmVzcG9uc2VcbiAgICApOiBQcm9taXNlPElPcGVuU2VhcmNoRGFzaGJvYXJkc1Jlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuYXV0aGluZm8nKTtcblxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IGVzUmVzcCxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogR2V0cyBhdWRpdCBsb2cgY29uZmlndXJhdGlvbuOAglxuICAgKlxuICAgKiBTYW1wbGUgcGF5bG9hZDpcbiAgICoge1xuICAgKiAgIFwiZW5hYmxlZFwiOnRydWUsXG4gICAqICAgXCJhdWRpdFwiOntcbiAgICogICAgIFwiZW5hYmxlX3Jlc3RcIjpmYWxzZSxcbiAgICogICAgIFwiZGlzYWJsZWRfcmVzdF9jYXRlZ29yaWVzXCI6W1xuICAgKiAgICAgICBcIkZBSUxFRF9MT0dJTlwiLFxuICAgKiAgICAgICBcIkFVVEhFTlRJQ0FURURcIlxuICAgKiAgICAgXSxcbiAgICogICAgIFwiZW5hYmxlX3RyYW5zcG9ydFwiOnRydWUsXG4gICAqICAgICBcImRpc2FibGVkX3RyYW5zcG9ydF9jYXRlZ29yaWVzXCI6W1xuICAgKiAgICAgICBcIkdSQU5URURfUFJJVklMRUdFU1wiXG4gICAqICAgICBdLFxuICAgKiAgICAgXCJyZXNvbHZlX2J1bGtfcmVxdWVzdHNcIjp0cnVlLFxuICAgKiAgICAgXCJsb2dfcmVxdWVzdF9ib2R5XCI6ZmFsc2UsXG4gICAqICAgICBcInJlc29sdmVfaW5kaWNlc1wiOnRydWUsXG4gICAqICAgICBcImV4Y2x1ZGVfc2Vuc2l0aXZlX2hlYWRlcnNcIjp0cnVlLFxuICAgKiAgICAgXCJpZ25vcmVfdXNlcnNcIjpbXG4gICAqICAgICAgIFwiYWRtaW5cIixcbiAgICogICAgIF0sXG4gICAqICAgICBcImlnbm9yZV9yZXF1ZXN0c1wiOltcbiAgICogICAgICAgXCJTZWFyY2hSZXF1ZXN0XCIsXG4gICAqICAgICAgIFwiaW5kaWNlczpkYXRhL3JlYWQvKlwiXG4gICAqICAgICBdXG4gICAqICAgfSxcbiAgICogICBcImNvbXBsaWFuY2VcIjp7XG4gICAqICAgICBcImVuYWJsZWRcIjp0cnVlLFxuICAgKiAgICAgXCJpbnRlcm5hbF9jb25maWdcIjpmYWxzZSxcbiAgICogICAgIFwiZXh0ZXJuYWxfY29uZmlnXCI6ZmFsc2UsXG4gICAqICAgICBcInJlYWRfbWV0YWRhdGFfb25seVwiOmZhbHNlLFxuICAgKiAgICAgXCJyZWFkX3dhdGNoZWRfZmllbGRzXCI6e1xuICAgKiAgICAgICBcImluZGV4TmFtZTFcIjpbXG4gICAqICAgICAgICAgXCJmaWVsZDFcIixcbiAgICogICAgICAgICBcImZpZWxkcy0qXCJcbiAgICogICAgICAgXVxuICAgKiAgICAgfSxcbiAgICogICAgIFwicmVhZF9pZ25vcmVfdXNlcnNcIjpbXG4gICAqICAgICAgIFwib3BlbnNlYXJjaGRhc2hib2FyZHNzZXJ2ZXJcIixcbiAgICogICAgICAgXCJvcGVyYXRvci8qXCJcbiAgICogICAgIF0sXG4gICAqICAgICBcIndyaXRlX21ldGFkYXRhX29ubHlcIjpmYWxzZSxcbiAgICogICAgIFwid3JpdGVfbG9nX2RpZmZzXCI6ZmFsc2UsXG4gICAqICAgICBcIndyaXRlX3dhdGNoZWRfaW5kaWNlc1wiOltcbiAgICogICAgICAgXCJpbmRleE5hbWUyXCIsXG4gICAqICAgICAgIFwiaW5kZXhQYXR0ZXJucy0qXCJcbiAgICogICAgIF0sXG4gICAqICAgICBcIndyaXRlX2lnbm9yZV91c2Vyc1wiOltcbiAgICogICAgICAgXCJhZG1pblwiXG4gICAqICAgICBdXG4gICAqICAgfVxuICAgKiB9XG4gICAqL1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0FQSV9QUkVGSVh9L2NvbmZpZ3VyYXRpb24vYXVkaXRgLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKFxuICAgICAgY29udGV4dCxcbiAgICAgIHJlcXVlc3QsXG4gICAgICByZXNwb25zZVxuICAgICk6IFByb21pc2U8SU9wZW5TZWFyY2hEYXNoYm9hcmRzUmVzcG9uc2U8YW55IHwgUmVzcG9uc2VFcnJvcj4+ID0+IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xuXG4gICAgICBsZXQgZXNSZXNwO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LmdldEF1ZGl0Jyk7XG5cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiBlc1Jlc3AsXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzQ29kZSxcbiAgICAgICAgICBib2R5OiBwYXJzZUVzRXJyb3JSZXNwb25zZShlcnJvciksXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogVXBkYXRlIGF1ZGl0IGxvZyBjb25maWd1cmF0aW9u44CCXG4gICAqXG4gICAqIFNhbXBsZSBwYXlsb2FkOlxuICAgKiB7XG4gICAqICAgXCJlbmFibGVkXCI6dHJ1ZSxcbiAgICogICBcImF1ZGl0XCI6e1xuICAgKiAgICAgXCJlbmFibGVfcmVzdFwiOmZhbHNlLFxuICAgKiAgICAgXCJkaXNhYmxlZF9yZXN0X2NhdGVnb3JpZXNcIjpbXG4gICAqICAgICAgIFwiRkFJTEVEX0xPR0lOXCIsXG4gICAqICAgICAgIFwiQVVUSEVOVElDQVRFRFwiXG4gICAqICAgICBdLFxuICAgKiAgICAgXCJlbmFibGVfdHJhbnNwb3J0XCI6dHJ1ZSxcbiAgICogICAgIFwiZGlzYWJsZWRfdHJhbnNwb3J0X2NhdGVnb3JpZXNcIjpbXG4gICAqICAgICAgIFwiR1JBTlRFRF9QUklWSUxFR0VTXCJcbiAgICogICAgIF0sXG4gICAqICAgICBcInJlc29sdmVfYnVsa19yZXF1ZXN0c1wiOnRydWUsXG4gICAqICAgICBcImxvZ19yZXF1ZXN0X2JvZHlcIjpmYWxzZSxcbiAgICogICAgIFwicmVzb2x2ZV9pbmRpY2VzXCI6dHJ1ZSxcbiAgICogICAgIFwiZXhjbHVkZV9zZW5zaXRpdmVfaGVhZGVyc1wiOnRydWUsXG4gICAqICAgICBcImlnbm9yZV91c2Vyc1wiOltcbiAgICogICAgICAgXCJhZG1pblwiLFxuICAgKiAgICAgXSxcbiAgICogICAgIFwiaWdub3JlX3JlcXVlc3RzXCI6W1xuICAgKiAgICAgICBcIlNlYXJjaFJlcXVlc3RcIixcbiAgICogICAgICAgXCJpbmRpY2VzOmRhdGEvcmVhZC8qXCJcbiAgICogICAgIF1cbiAgICogICB9LFxuICAgKiAgIFwiY29tcGxpYW5jZVwiOntcbiAgICogICAgIFwiZW5hYmxlZFwiOnRydWUsXG4gICAqICAgICBcImludGVybmFsX2NvbmZpZ1wiOmZhbHNlLFxuICAgKiAgICAgXCJleHRlcm5hbF9jb25maWdcIjpmYWxzZSxcbiAgICogICAgIFwicmVhZF9tZXRhZGF0YV9vbmx5XCI6ZmFsc2UsXG4gICAqICAgICBcInJlYWRfd2F0Y2hlZF9maWVsZHNcIjp7XG4gICAqICAgICAgIFwiaW5kZXhOYW1lMVwiOltcbiAgICogICAgICAgICBcImZpZWxkMVwiLFxuICAgKiAgICAgICAgIFwiZmllbGRzLSpcIlxuICAgKiAgICAgICBdXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJyZWFkX2lnbm9yZV91c2Vyc1wiOltcbiAgICogICAgICAgXCJraWJhbmFzZXJ2ZXJcIixcbiAgICogICAgICAgXCJvcGVyYXRvci8qXCJcbiAgICogICAgIF0sXG4gICAqICAgICBcIndyaXRlX21ldGFkYXRhX29ubHlcIjpmYWxzZSxcbiAgICogICAgIFwid3JpdGVfbG9nX2RpZmZzXCI6ZmFsc2UsXG4gICAqICAgICBcIndyaXRlX3dhdGNoZWRfaW5kaWNlc1wiOltcbiAgICogICAgICAgXCJpbmRleE5hbWUyXCIsXG4gICAqICAgICAgIFwiaW5kZXhQYXR0ZXJucy0qXCJcbiAgICogICAgIF0sXG4gICAqICAgICBcIndyaXRlX2lnbm9yZV91c2Vyc1wiOltcbiAgICogICAgICAgXCJhZG1pblwiXG4gICAqICAgICBdXG4gICAqICAgfVxuICAgKiB9XG4gICAqL1xuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS9jb25maWd1cmF0aW9uL2F1ZGl0L2NvbmZpZ2AsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEuYW55KCksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuc2F2ZUF1ZGl0Jywge1xuICAgICAgICAgIGJvZHk6IHJlcXVlc3QuYm9keSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgbWVzc2FnZTogZXNSZXNwLm1lc3NhZ2UsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogRGVsZXRlcyBjYWNoZS5cbiAgICpcbiAgICogU2FtcGxlIHJlc3BvbnNlOiB7XCJtZXNzYWdlXCI6XCJDYWNoZSBmbHVzaGVkIHN1Y2Nlc3NmdWxseS5cIn1cbiAgICovXG4gIHJvdXRlci5kZWxldGUoXG4gICAge1xuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vY29uZmlndXJhdGlvbi9jYWNoZWAsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xuICAgICAgbGV0IGVzUmVzcG9uc2U7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3BvbnNlID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LmNsZWFyQ2FjaGUnKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBtZXNzYWdlOiBlc1Jlc3BvbnNlLm1lc3NhZ2UsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogR2V0cyBwZXJtaXNzaW9uIGluZm8gb2YgY3VycmVudCB1c2VyLlxuICAgKlxuICAgKiBTYW1wbGUgcmVzcG9uc2U6XG4gICAqIHtcbiAgICogICBcInVzZXJcIjogXCJVc2VyIFtuYW1lPWFkbWluLCByb2xlcz1bXSwgcmVxdWVzdGVkVGVuYW50PV9fdXNlcl9fXVwiLFxuICAgKiAgIFwidXNlcl9uYW1lXCI6IFwiYWRtaW5cIixcbiAgICogICBcImhhc19hcGlfYWNjZXNzXCI6IHRydWUsXG4gICAqICAgXCJkaXNhYmxlZF9lbmRwb2ludHNcIjoge31cbiAgICogfVxuICAgKi9cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS9yZXN0YXBpaW5mb2AsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZXNSZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb3BlbnNlYXJjaF9zZWN1cml0eS5yZXN0YXBpaW5mbycpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IGVzUmVzcG9uc2UsXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJhZFJlcXVlc3Qoe1xuICAgICAgICAgIGJvZHk6IGVycm9yLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlcyBETFMgKGRvY3VtZW50IGxldmVsIHNlY3VyaXR5KSBxdWVyeS5cbiAgICpcbiAgICogUmVxdWVzdCBwYXlsb2FkIGlzIGFuIEVTIHF1ZXJ5LlxuICAgKi9cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vJHtDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVh9L3ZhbGlkYXRlZGxzL3tpbmRleE5hbWV9YCxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgLy8gaW4gbGVnYWN5IHBsdWdpbiBpbXBsbWVudGF0aW9uLCBpbmRleE5hbWUgaXMgbm90IHVzZWQgd2hlbiBjYWxsaW5nIEVTIEFQSS5cbiAgICAgICAgICBpbmRleE5hbWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBlc1Jlc3BvbnNlID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LnZhbGlkYXRlRGxzJywge1xuICAgICAgICAgIGJvZHk6IHJlcXVlc3QuYm9keSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogZXNSZXNwb25zZSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogR2V0cyBpbmRleCBtYXBwaW5nLlxuICAgKlxuICAgKiBDYWxsaW5nIEVTIF9tYXBwaW5nIEFQSSB1bmRlciB0aGUgaG9vZC4gc2VlXG4gICAqIGh0dHBzOi8vd3d3LmVsYXN0aWMuY28vZ3VpZGUvZW4vZWxhc3RpY3NlYXJjaC9yZWZlcmVuY2UvY3VycmVudC9pbmRpY2VzLWdldC1tYXBwaW5nLmh0bWxcbiAgICovXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0FQSV9QUkVGSVh9LyR7Q09ORklHVVJBVElPTl9BUElfUFJFRklYfS9pbmRleF9tYXBwaW5nc2AsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpbmRleDogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGVzUmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5zZWFyY2hfc2VjdXJpdHkuZ2V0SW5kZXhNYXBwaW5ncycsIHtcbiAgICAgICAgICBpbmRleDogcmVxdWVzdC5ib2R5LmluZGV4LmpvaW4oJywnKSxcbiAgICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICAgICAgYWxsb3dfbm9faW5kaWNlczogdHJ1ZSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiBlc1Jlc3BvbnNlLFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBHZXRzIGFsbCBpbmRpY2VzLCBhbmQgZmllbGQgbWFwcGluZ3MuXG4gICAqXG4gICAqIENhbGxzIEVTIEFQSSAnL19hbGwvX21hcHBpbmcvZmllbGQvKicgdW5kZXIgdGhlIGhvb2QuIHNlZVxuICAgKiBodHRwczovL3d3dy5lbGFzdGljLmNvL2d1aWRlL2VuL2VsYXN0aWNzZWFyY2gvcmVmZXJlbmNlL2N1cnJlbnQvaW5kaWNlcy1nZXQtbWFwcGluZy5odG1sXG4gICAqL1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0FQSV9QUkVGSVh9LyR7Q09ORklHVVJBVElPTl9BUElfUFJFRklYfS9pbmRpY2VzYCxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBlc1Jlc3BvbnNlID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuc2VhcmNoX3NlY3VyaXR5LmluZGljZXMnKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiBlc1Jlc3BvbnNlLFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuICApO1xufVxuXG5mdW5jdGlvbiBwYXJzZUVzRXJyb3JSZXNwb25zZShlcnJvcjogYW55KSB7XG4gIGlmIChlcnJvci5yZXNwb25zZSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBlc0Vycm9yUmVzcG9uc2UgPSBKU09OLnBhcnNlKGVycm9yLnJlc3BvbnNlKTtcbiAgICAgIHJldHVybiBlc0Vycm9yUmVzcG9uc2UucmVhc29uIHx8IGVycm9yLnJlc3BvbnNlO1xuICAgIH0gY2F0Y2ggKHBhcnNpbmdFcnJvcikge1xuICAgICAgcmV0dXJuIGVycm9yLnJlc3BvbnNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZXJyb3IubWVzc2FnZTtcbn1cblxuZnVuY3Rpb24gZXJyb3JSZXNwb25zZShyZXNwb25zZTogT3BlblNlYXJjaERhc2hib2FyZHNSZXNwb25zZUZhY3RvcnksIGVycm9yOiBhbnkpIHtcbiAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbSh7XG4gICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzQ29kZSxcbiAgICBib2R5OiBwYXJzZUVzRXJyb3JSZXNwb25zZShlcnJvciksXG4gIH0pO1xufVxuIl19